"""
ui_panel.py – omni.ui window for the Motion Path Sim extension.

Layout
------
┌─ Motion Path Sim ──────────────────────────────────┐
│  Path Prim   [/World/PathCurve          ] [Pick]  │
│  Target Prim [/World/Vehicle            ] [Pick]  │
│  Duration    [  5.00  ] s                          │
│  Align to path  ☐                                  │
│  Apply orientation  ☐                              │
│  ──────────────────────────────────────────────    │
│  [  Build Graph  ]                                  │
│  [    Start    ] [  Pause  ] [   Stop   ]          │
│  Status: STOPPED                                   │
└────────────────────────────────────────────────────┘

Graph path
----------
The OmniGraph is built at ``/World/Graphs/MotionPathSimGraph`` the first
time "Build Graph" is pressed.  Subsequent presses rebuild it from scratch.
"""

from __future__ import annotations

import logging
from typing import Optional

import omni.kit.app
import omni.ui as ui

from .playback_controller import PlaybackController, PlaybackState

log = logging.getLogger(__name__)

_GRAPH_PATH = "/World/Graphs/MotionPathSimGraph"
_WINDOW_TITLE = "Motion Path Sim"
_WINDOW_WIDTH = 380
_WINDOW_HEIGHT = 260

_BTN_H = 24
_LABEL_W = 100
_FIELD_W = 200
_PICK_W = 44


class MotionPathSimPanel:
    """Main UI window for Motion Path Sim."""

    def __init__(self) -> None:
        self._window: Optional[ui.Window] = None
        self._ctrl: Optional[PlaybackController] = None
        self._graph_built: bool = False

        # Model-backed widgets (kept alive to read values)
        self._path_prim_model: ui.SimpleStringModel = ui.SimpleStringModel(
            "/World/PathCurve"
        )
        self._target_prim_model: ui.SimpleStringModel = ui.SimpleStringModel(
            "/World/Vehicle"
        )
        self._duration_model: ui.SimpleFloatModel = ui.SimpleFloatModel(5.0)
        self._align_model: ui.SimpleBoolModel = ui.SimpleBoolModel(False)
        self._apply_orient_model: ui.SimpleBoolModel = ui.SimpleBoolModel(False)

        # Status label (updated by state machine callback)
        self._status_label: Optional[ui.Label] = None
        self._pause_btn: Optional[ui.Button] = None

        self._build_window()

    # ── Window construction ─────────────────────────────────────────────────

    def _build_window(self) -> None:
        self._window = ui.Window(
            _WINDOW_TITLE,
            width=_WINDOW_WIDTH,
            height=_WINDOW_HEIGHT,
            flags=ui.WINDOW_FLAGS_NO_SCROLLBAR,
            visible=True,
        )
        self._window.deferred_dock_in(
            "Property", ui.DockPolicy.DO_NOT_DOCK_IN_WINDOW
        )
        with self._window.frame:
            with ui.VStack(spacing=6, style={"margin": 6}):
                self._build_prim_row("Path Prim", self._path_prim_model)
                self._build_prim_row("Target Prim", self._target_prim_model)
                self._build_duration_row()
                self._build_checkboxes()
                ui.Spacer(height=4)
                ui.Separator()
                ui.Spacer(height=4)
                self._build_build_button()
                self._build_playback_buttons()
                self._build_status_row()

    def _build_prim_row(
        self, label_text: str, model: ui.SimpleStringModel
    ) -> None:
        with ui.HStack(height=_BTN_H, spacing=4):
            ui.Label(label_text, width=_LABEL_W, alignment=ui.Alignment.RIGHT_CENTER)
            ui.StringField(model=model, width=_FIELD_W)
            ui.Button(
                "Pick",
                width=_PICK_W,
                height=_BTN_H,
                clicked_fn=lambda m=model: self._pick_from_selection(m),
                tooltip="Populate from current viewport selection",
            )

    def _build_duration_row(self) -> None:
        with ui.HStack(height=_BTN_H, spacing=4):
            ui.Label("Duration", width=_LABEL_W, alignment=ui.Alignment.RIGHT_CENTER)
            ui.FloatField(
                model=self._duration_model,
                width=80,
                precision=2,
                tooltip="Animation duration in seconds",
            )
            ui.Label("s", width=16)

    def _build_checkboxes(self) -> None:
        with ui.HStack(height=_BTN_H, spacing=8):
            ui.Label(
                "Align to path",
                width=_LABEL_W,
                alignment=ui.Alignment.RIGHT_CENTER,
                tooltip="Orient the target prim along the path tangent",
            )
            ui.CheckBox(model=self._align_model, width=20)
            ui.Spacer(width=16)
            ui.Label(
                "Apply orientation",
                alignment=ui.Alignment.RIGHT_CENTER,
                tooltip="Write orientation xform op on the target prim",
            )
            ui.CheckBox(model=self._apply_orient_model, width=20)

    def _build_build_button(self) -> None:
        with ui.HStack(height=_BTN_H):
            ui.Spacer()
            ui.Button(
                "Build Graph",
                width=120,
                height=_BTN_H,
                clicked_fn=self._on_build_graph,
                tooltip="Create (or recreate) the OmniGraph action graph",
                style={"Button": {"background_color": 0xFF444466}},
            )
            ui.Spacer()

    def _build_playback_buttons(self) -> None:
        with ui.HStack(height=_BTN_H, spacing=4):
            ui.Spacer()
            ui.Button(
                "Start",
                width=80,
                height=_BTN_H,
                clicked_fn=self._on_start,
                style={"Button": {"background_color": 0xFF336633}},
            )
            self._pause_btn = ui.Button(
                "Pause",
                width=80,
                height=_BTN_H,
                clicked_fn=self._on_pause_resume,
                style={"Button": {"background_color": 0xFF666633}},
            )
            ui.Button(
                "Stop",
                width=80,
                height=_BTN_H,
                clicked_fn=self._on_stop,
                style={"Button": {"background_color": 0xFF663333}},
            )
            ui.Spacer()

    def _build_status_row(self) -> None:
        with ui.HStack(height=_BTN_H):
            ui.Label("Status:", width=54)
            self._status_label = ui.Label(
                "STOPPED",
                style={"color": 0xFFAAAAAA},
            )

    # ── User action handlers ────────────────────────────────────────────────

    def _pick_from_selection(self, model: ui.SimpleStringModel) -> None:
        """Populate a string field with the path of the first selected prim."""
        try:
            import omni.usd
            ctx = omni.usd.get_context()
            selection = ctx.get_selection().get_selected_prim_paths()
            if selection:
                model.set_value(selection[0])
            else:
                log.warning("Nothing selected in the viewport")
        except Exception as exc:  # pylint: disable=broad-except
            log.error("_pick_from_selection error: %s", exc)

    def _on_build_graph(self) -> None:
        """Create or recreate the OmniGraph and wire all nodes."""
        try:
            self._stop_if_playing()
            self._build_omnigraph()
        except Exception as exc:  # pylint: disable=broad-except
            log.error("Build graph failed: %s", exc, exc_info=True)

    def _on_start(self) -> None:
        if not self._graph_built:
            # Auto-build on first Start press
            try:
                self._build_omnigraph()
            except Exception as exc:
                log.error("Auto-build failed: %s", exc, exc_info=True)
                return

        if self._ctrl is None:
            self._ctrl = PlaybackController(
                _GRAPH_PATH,
                duration=self._duration_model.as_float,
                on_state_change=self._on_state_change,
            )
        else:
            self._ctrl.duration = self._duration_model.as_float

        if self._ctrl.state == PlaybackState.STOPPED:
            self._ctrl.start()
        else:
            log.warning("Start pressed while not STOPPED — ignoring")

    def _on_pause_resume(self) -> None:
        if self._ctrl is None:
            return
        if self._ctrl.state == PlaybackState.PLAYING:
            self._ctrl.pause()
        elif self._ctrl.state == PlaybackState.PAUSED:
            self._ctrl.resume()

    def _on_stop(self) -> None:
        if self._ctrl is not None:
            self._ctrl.stop()

    def _stop_if_playing(self) -> None:
        if self._ctrl is not None and self._ctrl.state != PlaybackState.STOPPED:
            self._ctrl.stop()

    # ── State-change callback ───────────────────────────────────────────────

    def _on_state_change(self, new_state: PlaybackState) -> None:
        """Called by PlaybackController when the state changes."""
        state_str = new_state.value.upper()
        color_map = {
            PlaybackState.STOPPED: 0xFFAAAAAA,
            PlaybackState.PLAYING: 0xFF88FF88,
            PlaybackState.PAUSED: 0xFFFFDD88,
        }
        color = color_map.get(new_state, 0xFFFFFFFF)

        # Update status label
        if self._status_label is not None:
            self._status_label.text = state_str
            self._status_label.set_style({"color": color})

        # Update Pause/Resume button label
        if self._pause_btn is not None:
            if new_state == PlaybackState.PAUSED:
                self._pause_btn.text = "Resume"
            else:
                self._pause_btn.text = "Pause"

    # ── Graph construction ──────────────────────────────────────────────────

    def _build_omnigraph(self) -> None:
        """
        Build the OmniGraph pipeline:

            ReadPathPoints
               ├─ outputs:points      → PathInterpolate.inputs:points
               └─ outputs:pointCount  → PathInterpolate.inputs:pointCount

            PathInterpolate
               ├─ outputs:position    → ApplyXform.inputs:position
               └─ outputs:orientation → ApplyXform.inputs:orientation

        normalizedTime is set directly by PlaybackController each frame.
        """
        import omni.graph.core as og

        path_prim = self._path_prim_model.get_value_as_string()
        target_prim = self._target_prim_model.get_value_as_string()
        align = self._align_model.get_value_as_bool()
        apply_orient = self._apply_orient_model.get_value_as_bool()

        # Delete existing graph if present so we start clean
        self._delete_graph_if_exists(_GRAPH_PATH)

        try:
            (graph, nodes, _, _) = og.Controller.edit(
                {
                    "graph_path": _GRAPH_PATH,
                    "evaluator_name": "push",
                    "fc_backing_type": og.GraphBackingType.GRAPH_BACKING_TYPE_FLATCACHE_SHARED,
                },
                {
                    og.Controller.Keys.CREATE_NODES: [
                        ("ReadPathPoints", "motion.path.sim.ReadPathPoints"),
                        ("PathInterpolate", "motion.path.sim.PathInterpolate"),
                        ("ApplyXform", "motion.path.sim.ApplyXform"),
                    ],
                    og.Controller.Keys.CONNECT: [
                        (
                            "ReadPathPoints.outputs:points",
                            "PathInterpolate.inputs:points",
                        ),
                        (
                            "ReadPathPoints.outputs:pointCount",
                            "PathInterpolate.inputs:pointCount",
                        ),
                        (
                            "PathInterpolate.outputs:position",
                            "ApplyXform.inputs:position",
                        ),
                        (
                            "PathInterpolate.outputs:orientation",
                            "ApplyXform.inputs:orientation",
                        ),
                    ],
                    og.Controller.Keys.SET_VALUES: [
                        ("ReadPathPoints.inputs:primPath", path_prim),
                        ("ReadPathPoints.inputs:attributeName", "points"),
                        ("PathInterpolate.inputs:normalizedTime", 0.0),
                        ("PathInterpolate.inputs:align", align),
                        ("ApplyXform.inputs:targetPrimPath", target_prim),
                        ("ApplyXform.inputs:applyOrientation", apply_orient),
                    ],
                },
            )
        except Exception as exc:
            log.error("og.Controller.edit failed: %s", exc, exc_info=True)
            raise

        # Perform an initial evaluation so the target prim snaps to t=0
        if graph and graph.is_valid():
            graph.evaluate()

        self._graph_built = True

        # Recreate the controller bound to the new graph
        self._ctrl = PlaybackController(
            _GRAPH_PATH,
            duration=self._duration_model.as_float,
            on_state_change=self._on_state_change,
        )

        log.info(
            "OmniGraph built at %s  path='%s'  target='%s'",
            _GRAPH_PATH,
            path_prim,
            target_prim,
        )

    @staticmethod
    def _delete_graph_if_exists(graph_path: str) -> None:
        """Remove a previously built graph so we can rebuild cleanly."""
        try:
            import omni.usd
            stage = omni.usd.get_context().get_stage()
            if stage is None:
                return
            prim = stage.GetPrimAtPath(graph_path)
            if prim.IsValid():
                stage.RemovePrim(graph_path)
        except Exception as exc:  # pylint: disable=broad-except
            log.warning("Could not remove old graph at %s: %s", graph_path, exc)

    # ── Lifecycle ───────────────────────────────────────────────────────────

    def destroy(self) -> None:
        """Called by extension.py on_shutdown."""
        if self._ctrl is not None:
            self._ctrl.destroy()
            self._ctrl = None
        if self._window is not None:
            self._window.destroy()
            self._window = None
