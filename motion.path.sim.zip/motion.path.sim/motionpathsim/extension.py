"""
extension.py – entry point for the motion.path.sim Kit 109 extension.

Responsibilities
----------------
1. Register the three custom OmniGraph node types on startup.
2. Open the UI panel (omni.ui window).
3. Deregister nodes and close the UI on shutdown.

Node registration
-----------------
Kit 109 discovers Python OGN nodes via the ``[ogn]`` section in
``extension.toml`` (``python.module = "motion.path.sim"``).  It scans for
``.ogn`` files in the module tree and registers each node type at extension
load time — no separate build step is required for Python nodes.

As a belt-and-suspenders measure, ``_register_nodes()`` below also calls
``og.register_node_type()`` explicitly so the nodes are available even if the
auto-discovery path is disabled or unavailable in a non-standard Kit build.
"""

from __future__ import annotations

import json
import logging
import os
from typing import List, Optional

import omni.ext
import omni.graph.core as og
import omni.kit.ui

log = logging.getLogger(__name__)

# Fully-qualified OmniGraph type names
_NODE_TYPES: List[str] = [
    "motion.path.sim.ReadPathPoints",
    "motion.path.sim.PathInterpolate",
    "motion.path.sim.ApplyXform",
]


class MotionPathSimExtension(omni.ext.IExt):
    """Kit extension entry point."""

    def on_startup(self, ext_id: str) -> None:
        log.info("motion.path.sim starting up (ext_id=%s)", ext_id)
        self._ui_panel: Optional[object] = None
        self._registered_types: List[str] = []

        self._register_nodes()
        try:
            self._open_ui()
        except Exception as exc:
            import traceback
            log.error("UI open failed: %s\n%s", exc, traceback.format_exc())
        self._editor_menu = omni.kit.ui.get_editor_menu()
        self._menu_item = None
        if self._editor_menu:
            self._menu_item = self._editor_menu.add_item(
                "Window/Motion Path Sim",
                lambda *_: self._open_ui(),
                toggle=True,
                value=True,
            )

    def on_shutdown(self) -> None:
        log.info("motion.path.sim shutting down")
        if getattr(self, "_editor_menu", None) and getattr(self, "_menu_item", None):
            self._editor_menu.remove_item(self._menu_item)
        self._close_ui()
        self._deregister_nodes()

    # ── Node registration ───────────────────────────────────────────────────

    def _register_nodes(self) -> None:
        """
        Explicitly register each OGN Python node type.

        The .ogn JSON file is loaded to obtain the schema; the Python
        implementation class is discovered by module name convention.
        """
        nodes_dir = os.path.join(os.path.dirname(__file__), "nodes")

        registrations = [
            (
                "ReadPathPoints",
                "motionpathsim.nodes.ReadPathPoints",
                "OgnReadPathPoints",
            ),
            (
                "PathInterpolate",
                "motionpathsim.nodes.PathInterpolate",
                "OgnPathInterpolate",
            ),
            (
                "ApplyXform",
                "motionpathsim.nodes.ApplyXform",
                "OgnApplyXform",
            ),
        ]

        for ogn_name, module_name, class_name in registrations:
            ogn_path = os.path.join(nodes_dir, f"{ogn_name}.ogn")
            self._register_one_node(ogn_path, module_name, class_name)

    def _register_one_node(
        self, ogn_path: str, module_name: str, class_name: str
    ) -> None:
        """Load the .ogn schema and register the node type."""
        try:
            if not os.path.isfile(ogn_path):
                log.error("OGN file not found: %s", ogn_path)
                return

            # Import the Python implementation class
            import importlib
            mod = importlib.import_module(module_name)
            impl_class = getattr(mod, class_name)

            # Kit 109: register_node_type accepts the path to a .ogn file
            # plus the Python implementation class.
            og.register_node_type(ogn_path, impl_class)

            # Determine the fully-qualified type name from the .ogn file
            with open(ogn_path, "r", encoding="utf-8") as fh:
                schema = json.load(fh)
            # Top-level key is the node base name; full name = extension + "." + base
            base_name = next(iter(schema))
            full_type = f"motion.path.sim.{base_name}"
            self._registered_types.append(full_type)
            log.info("Registered OGN node: %s", full_type)

        except Exception as exc:  # pylint: disable=broad-except
            log.error(
                "Failed to register node from %s: %s", ogn_path, exc, exc_info=True
            )

    def _deregister_nodes(self) -> None:
        for type_name in self._registered_types:
            try:
                og.deregister_node_type(type_name)
                log.info("Deregistered OGN node: %s", type_name)
            except Exception as exc:  # pylint: disable=broad-except
                log.warning("Could not deregister %s: %s", type_name, exc)
        self._registered_types.clear()

    # ── UI lifecycle ────────────────────────────────────────────────────────

    def _open_ui(self) -> None:
        import omni.ui as ui
        try:
            self._ui_panel = ui.Window(
                "Motion Path Sim TEST",
                width=400,
                height=300,
                visible=True,
            )
            with self._ui_panel.frame:
                ui.Label("Motion Path Sim is working")
            import logging
            logging.getLogger(__name__).warning(
                "TEST WINDOW CREATED: visible=%s", self._ui_panel.visible
            )
        except Exception as exc:
            import traceback
            logging.getLogger(__name__).error(
                "TEST WINDOW FAILED: %s\n%s", exc, traceback.format_exc()
            )

    def _close_ui(self) -> None:
        if self._ui_panel is not None:
            try:
                self._ui_panel.destroy()
            except Exception:
                pass
            self._ui_panel = None
