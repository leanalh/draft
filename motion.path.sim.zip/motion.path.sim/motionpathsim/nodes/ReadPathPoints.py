"""
ReadPathPoints OmniGraph node.

Reads a USD prim attribute (default: "points") and exposes the result as a
pointf[3][] array together with the element count.  This replaces the
deprecated omni.graph.nodes.ImportUSDData node.

Stable API: omni.graph.nodes.ReadPrimAttribute is the Kit 109+ approach;
this wrapper gives a single-purpose node that is easier to wire in the
Motion Path Sim graph.
"""

import logging

import numpy as np

log = logging.getLogger(__name__)


class OgnReadPathPoints:
    """
    OmniGraph Python node: Read Path Points.

    Inputs
    ------
    primPath      : token  – absolute USD path, e.g. "/World/PathCurve"
    attributeName : token  – attribute to read, default "points"

    Outputs
    -------
    points      : pointf[3][]  – world-space positions
    pointCount  : int          – number of points (0 on failure)
    """

    @staticmethod
    def compute(db) -> bool:  # type: ignore[override]
        """Evaluate node: fetch attribute from USD stage and push to outputs."""
        try:
            prim_path: str = str(db.inputs.primPath)
            attr_name: str = str(db.inputs.attributeName) or "points"

            if not prim_path:
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return True

            import omni.usd
            stage = omni.usd.get_context().get_stage()
            if stage is None:
                db.log_warning("ReadPathPoints: no USD stage available")
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return False

            prim = stage.GetPrimAtPath(prim_path)
            if not prim.IsValid():
                db.log_warning(f"ReadPathPoints: prim not found at '{prim_path}'")
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return False

            attr = prim.GetAttribute(attr_name)
            if not attr.IsValid():
                db.log_warning(
                    f"ReadPathPoints: attribute '{attr_name}' not found on '{prim_path}'"
                )
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return False

            value = attr.Get()
            if value is None:
                db.log_warning(
                    f"ReadPathPoints: attribute '{attr_name}' returned None"
                )
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return False

            # Convert VtArray[GfVec3f] (or any sequence of 3-tuples) to numpy
            points_np = np.array(value, dtype=np.float32)

            # Ensure shape (N, 3)
            if points_np.ndim == 1 and points_np.size == 3:
                points_np = points_np.reshape(1, 3)
            elif points_np.ndim != 2 or points_np.shape[1] != 3:
                db.log_error(
                    f"ReadPathPoints: unexpected shape {points_np.shape} for '{attr_name}'"
                )
                db.outputs.points = np.zeros((0, 3), dtype=np.float32)
                db.outputs.pointCount = 0
                return False

            db.outputs.points = points_np
            db.outputs.pointCount = int(points_np.shape[0])
            return True

        except Exception as exc:  # pylint: disable=broad-except
            db.log_error(f"ReadPathPoints compute error: {exc}")
            return False
