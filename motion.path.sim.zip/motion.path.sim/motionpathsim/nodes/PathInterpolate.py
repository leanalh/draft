"""
PathInterpolate OmniGraph node.

Given an ordered polyline of world-space points and a normalised time
t ∈ [0, 1], linearly interpolates position along the path.

When `align` is True the node also computes a forward-facing orientation
from the path tangent.  The output quaternion follows the OmniGraph
convention: [x, y, z, w] (imaginary components first, real component last),
equivalent to USD's GfQuatf with the real part moved to the end.

Z-up world-space is assumed.  The reference forward vector used for the
`align` rotation is (1, 0, 0).
"""

import logging
import math

import numpy as np

log = logging.getLogger(__name__)

# Identity quaternion [x, y, z, w]
_IDENTITY_QUAT = np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float32)


def _quat_from_vectors(v_from: np.ndarray, v_to: np.ndarray) -> np.ndarray:
    """
    Shortest-arc quaternion that rotates unit vector `v_from` to unit vector `v_to`.

    Returns [x, y, z, w] float32 array.
    """
    dot = float(np.dot(v_from, v_to))

    # Parallel case (same direction) → identity
    if dot >= 1.0 - 1e-6:
        return _IDENTITY_QUAT.copy()

    # Anti-parallel case → 180° around any perpendicular axis
    if dot <= -1.0 + 1e-6:
        perp = np.array([0.0, 1.0, 0.0], dtype=np.float64)
        if abs(v_from[1]) > 0.9:
            perp = np.array([1.0, 0.0, 0.0], dtype=np.float64)
        axis = np.cross(v_from, perp)
        norm = np.linalg.norm(axis)
        if norm < 1e-9:
            return _IDENTITY_QUAT.copy()
        axis /= norm
        return np.array([axis[0], axis[1], axis[2], 0.0], dtype=np.float32)

    # General case via half-angle trick
    axis = np.cross(v_from, v_to)
    w = 1.0 + dot
    length = math.sqrt(axis[0] ** 2 + axis[1] ** 2 + axis[2] ** 2 + w ** 2)
    if length < 1e-9:
        return _IDENTITY_QUAT.copy()
    scale = 1.0 / length
    return np.array(
        [axis[0] * scale, axis[1] * scale, axis[2] * scale, w * scale],
        dtype=np.float32,
    )


class OgnPathInterpolate:
    """
    OmniGraph Python node: Path Interpolate.

    Inputs
    ------
    points         : pointf[3][]  – ordered path waypoints
    pointCount     : int          – number of valid points
    normalizedTime : float        – playback progress in [0, 1]
    align          : bool         – compute tangent orientation when True

    Outputs
    -------
    position    : pointf[3]  – interpolated world-space position
    orientation : quatf      – [x, y, z, w] orientation (identity if align=False)
    """

    @staticmethod
    def compute(db) -> bool:  # type: ignore[override]
        """Evaluate node: interpolate along path at the given normalised time."""
        try:
            n: int = int(db.inputs.pointCount)
            t: float = float(db.inputs.normalizedTime)
            align: bool = bool(db.inputs.align)

            # Clamp t
            t = max(0.0, min(1.0, t))

            if n < 1:
                db.outputs.position = np.zeros(3, dtype=np.float32)
                db.outputs.orientation = _IDENTITY_QUAT.copy()
                return True

            # Retrieve points array; shape must be (N, 3)
            pts = np.asarray(db.inputs.points, dtype=np.float32)
            if pts.ndim == 1:
                pts = pts.reshape(-1, 3)
            n_actual = pts.shape[0]

            if n_actual == 0:
                db.outputs.position = np.zeros(3, dtype=np.float32)
                db.outputs.orientation = _IDENTITY_QUAT.copy()
                return True

            if n_actual == 1 or t <= 0.0:
                db.outputs.position = pts[0].copy()
                db.outputs.orientation = _IDENTITY_QUAT.copy()
                return True

            if t >= 1.0:
                db.outputs.position = pts[-1].copy()
                db.outputs.orientation = _IDENTITY_QUAT.copy()
                return True

            # Linear interpolation between segment endpoints
            # Segment index in [0, n_actual - 2]
            max_seg = n_actual - 1
            raw = t * max_seg
            seg_idx = int(math.floor(raw))
            seg_idx = min(seg_idx, max_seg - 1)  # safety clamp
            local_t = raw - seg_idx              # [0, 1) within segment

            p0 = pts[seg_idx].astype(np.float64)
            p1 = pts[seg_idx + 1].astype(np.float64)

            position = (p0 + local_t * (p1 - p0)).astype(np.float32)
            db.outputs.position = position

            if align:
                tangent = p1 - p0
                length = np.linalg.norm(tangent)
                if length > 1e-9:
                    tangent /= length
                else:
                    tangent = np.array([1.0, 0.0, 0.0], dtype=np.float64)

                # Reference forward axis: +X in Z-up world space
                forward = np.array([1.0, 0.0, 0.0], dtype=np.float64)
                db.outputs.orientation = _quat_from_vectors(forward, tangent)
            else:
                db.outputs.orientation = _IDENTITY_QUAT.copy()

            return True

        except Exception as exc:  # pylint: disable=broad-except
            db.log_error(f"PathInterpolate compute error: {exc}")
            return False
