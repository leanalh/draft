"""
ApplyXform OmniGraph node.

Side-effect node: writes a position (and optionally an orientation) to the
Xformable ops of a USD prim every time the graph evaluates.

USD xform ops written
---------------------
* ``xformOp:translate``  – always (GfVec3d)
* ``xformOp:orient``     – only when applyOrientation=True (GfQuatf)

Quaternion convention
---------------------
OmniGraph ``quatf``: [x, y, z, w]  (imaginary first, real last)
USD ``GfQuatf(real, imaginary)``   → GfQuatf(w, GfVec3f(x, y, z))
"""

import logging

import numpy as np

log = logging.getLogger(__name__)


class OgnApplyXform:
    """
    OmniGraph Python node: Apply Xform.

    Inputs
    ------
    targetPrimPath  : token      – absolute SdfPath of the prim to move
    position        : pointf[3]  – new world-space translation
    orientation     : quatf      – [x, y, z, w] rotation (if applyOrientation)
    applyOrientation: bool       – whether to write the orient op

    Outputs
    -------
    (none — this is a side-effect node)
    """

    @staticmethod
    def compute(db) -> bool:  # type: ignore[override]
        """Evaluate node: write transform to USD stage."""
        try:
            target_path: str = str(db.inputs.targetPrimPath)
            if not target_path:
                return True  # no-op until path is set

            import omni.usd
            from pxr import Gf, UsdGeom

            stage = omni.usd.get_context().get_stage()
            if stage is None:
                db.log_warning("ApplyXform: no USD stage available")
                return False

            prim = stage.GetPrimAtPath(target_path)
            if not prim.IsValid():
                db.log_warning(f"ApplyXform: prim not found at '{target_path}'")
                return False

            xformable = UsdGeom.Xformable(prim)
            if not xformable:
                db.log_warning(
                    f"ApplyXform: prim '{target_path}' is not Xformable"
                )
                return False

            # ── Translation ──────────────────────────────────────────────────
            pos = np.asarray(db.inputs.position, dtype=np.float64).ravel()
            if pos.size < 3:
                pos = np.zeros(3, dtype=np.float64)

            translate_ops = [
                op
                for op in xformable.GetOrderedXformOps()
                if op.GetOpType() == UsdGeom.XformOp.TypeTranslate
            ]
            if translate_ops:
                translate_op = translate_ops[0]
            else:
                translate_op = xformable.AddTranslateOp()

            translate_op.Set(Gf.Vec3d(float(pos[0]), float(pos[1]), float(pos[2])))

            # ── Orientation (optional) ────────────────────────────────────────
            apply_orient: bool = bool(db.inputs.applyOrientation)
            if apply_orient:
                # OmniGraph quatf: [x, y, z, w]  → GfQuatf(w, GfVec3f(x,y,z))
                q = np.asarray(db.inputs.orientation, dtype=np.float64).ravel()
                if q.size < 4:
                    q = np.array([0.0, 0.0, 0.0, 1.0])
                x, y, z, w = float(q[0]), float(q[1]), float(q[2]), float(q[3])
                gf_quat = Gf.Quatf(w, Gf.Vec3f(x, y, z))

                orient_ops = [
                    op
                    for op in xformable.GetOrderedXformOps()
                    if op.GetOpType() == UsdGeom.XformOp.TypeOrient
                ]
                if orient_ops:
                    orient_op = orient_ops[0]
                else:
                    orient_op = xformable.AddOrientOp()

                orient_op.Set(gf_quat)

            return True

        except Exception as exc:  # pylint: disable=broad-except
            db.log_error(f"ApplyXform compute error: {exc}")
            return False
