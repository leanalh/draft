"""
playback_controller.py – frame-accurate playback state machine.

State diagram
-------------
    STOPPED ──start()──► PLAYING ──pause()──► PAUSED
       ▲                    │                   │
       └──────stop()────────┘◄────resume()──────┘
       └──────stop()───────────────────────────┘

Timing
------
Elapsed time is accumulated from app-update delta-time events so playback
is independent of the USD timeline.  The PlaybackController writes the
normalised time (elapsed / duration) directly to the OmniGraph attribute
``inputs:normalizedTime`` on the PathInterpolate node and then calls
``graph.evaluate()`` to push results through the graph.

Usage
-----
    ctrl = PlaybackController("/World/Graphs/MotionPathSimGraph", duration=5.0)
    ctrl.start()
    ...
    ctrl.pause()
    ctrl.resume()
    ctrl.stop()
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Callable, Optional

log = logging.getLogger(__name__)


class PlaybackState(Enum):
    STOPPED = "stopped"
    PLAYING = "playing"
    PAUSED = "paused"


class PlaybackController:
    """
    Frame-accurate playback controller for the Motion Path Sim OmniGraph.

    Parameters
    ----------
    graph_path : str
        Absolute stage path to the OmniGraph, e.g.
        ``"/World/Graphs/MotionPathSimGraph"``.
    duration : float
        Total animation duration in seconds (> 0).
    on_state_change : optional callable
        Called with the new ``PlaybackState`` whenever the state changes.
        Useful for updating UI button labels.
    """

    def __init__(
        self,
        graph_path: str,
        duration: float = 5.0,
        on_state_change: Optional[Callable[[PlaybackState], None]] = None,
    ) -> None:
        self._graph_path: str = graph_path
        self._duration: float = max(duration, 0.001)
        self._on_state_change = on_state_change

        self._state: PlaybackState = PlaybackState.STOPPED
        self._elapsed: float = 0.0
        self._update_sub: Optional[carb.events.ISubscription] = None

    # ── Public interface ────────────────────────────────────────────────────

    @property
    def state(self) -> PlaybackState:
        return self._state

    @property
    def duration(self) -> float:
        return self._duration

    @duration.setter
    def duration(self, value: float) -> None:
        self._duration = max(value, 0.001)

    @property
    def graph_path(self) -> str:
        return self._graph_path

    @graph_path.setter
    def graph_path(self, value: str) -> None:
        self._graph_path = value

    def start(self) -> None:
        """Transition STOPPED → PLAYING.  Resets elapsed time to 0."""
        if self._state != PlaybackState.STOPPED:
            log.warning("PlaybackController.start() called while not STOPPED")
            return
        self._elapsed = 0.0
        self._subscribe_update()
        self._set_state(PlaybackState.PLAYING)

    def pause(self) -> None:
        """Transition PLAYING → PAUSED.  Keeps accumulated elapsed time."""
        if self._state != PlaybackState.PLAYING:
            log.warning("PlaybackController.pause() called while not PLAYING")
            return
        self._unsubscribe_update()
        self._set_state(PlaybackState.PAUSED)

    def resume(self) -> None:
        """Transition PAUSED → PLAYING.  Continues from saved elapsed time."""
        if self._state != PlaybackState.PAUSED:
            log.warning("PlaybackController.resume() called while not PAUSED")
            return
        self._subscribe_update()
        self._set_state(PlaybackState.PLAYING)

    def stop(self) -> None:
        """Transition any state → STOPPED.  Resets elapsed time and graph."""
        self._unsubscribe_update()
        self._elapsed = 0.0
        self._write_normalised_time(0.0)
        self._set_state(PlaybackState.STOPPED)

    def destroy(self) -> None:
        """Release subscriptions.  Call from extension on_shutdown."""
        self._unsubscribe_update()

    # ── Internal helpers ────────────────────────────────────────────────────

    def _set_state(self, new_state: PlaybackState) -> None:
        self._state = new_state
        log.debug("PlaybackController → %s", new_state.value)
        if self._on_state_change is not None:
            try:
                self._on_state_change(new_state)
            except Exception as exc:  # pylint: disable=broad-except
                log.error("on_state_change callback raised: %s", exc)

    def _subscribe_update(self) -> None:
        import omni.kit.app
        import carb.events
        if self._update_sub is not None:
            return  # already subscribed
        stream = omni.kit.app.get_app().get_update_event_stream()
        self._update_sub = stream.create_subscription_to_pop(
            self._on_update,
            name="motion.path.sim.playback_update",
        )

    def _unsubscribe_update(self) -> None:
        if self._update_sub is not None:
            self._update_sub = None  # releasing the ref unsubscribes

    def _on_update(self, event: carb.events.IEvent) -> None:
        """Called every app frame while PLAYING."""
        if self._state != PlaybackState.PLAYING:
            return

        dt: float = event.payload["dt"] if "dt" in event.payload else 0.016
        self._elapsed += dt

        normalised_t = self._elapsed / self._duration

        if normalised_t >= 1.0:
            # Clamp to end, push final frame, then stop
            self._write_normalised_time(1.0)
            self.stop()
            return

        self._write_normalised_time(normalised_t)

    def _write_normalised_time(self, t: float) -> None:
        """
        Push ``t`` into the OmniGraph PathInterpolate node's normalizedTime
        input and evaluate the graph so the transform updates immediately.
        """
        try:
            import omni.graph.core as og

            # Resolve node – graph may not exist yet during teardown
            node_path = f"{self._graph_path}/PathInterpolate"
            node = og.Controller.node(node_path)
            if not node.is_valid():
                return

            attr = og.Controller.attribute("inputs:normalizedTime", node)
            attr.set(float(t))

            graph = og.get_graph_by_path(self._graph_path)
            if graph and graph.is_valid():
                graph.evaluate()

        except Exception as exc:  # pylint: disable=broad-except
            # Non-fatal: graph may not be built yet
            log.debug("PlaybackController._write_normalised_time error: %s", exc)
