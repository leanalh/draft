# motion.path.sim

A Kit 109 extension that replicates and extends the **Motion Path (beta)** extension
using three custom OmniGraph nodes and a Python-driven playback state machine.

---

## Overview

| Component | Role |
|-----------|------|
| `ReadPathPoints` OGN node | Reads `points` (or any attribute) from a USD prim — replaces deprecated `ImportUSDData` |
| `PathInterpolate` OGN node | Linearly interpolates position + optional tangent orientation along the polyline |
| `ApplyXform` OGN node | Writes the resulting translation (+ optional orientation) to a USD prim |
| `PlaybackController` | Python state machine that drives `normalizedTime` each app frame |
| `MotionPathSimPanel` | `omni.ui` window: prim pickers, duration, Start / Pause-Resume / Stop |

---

## Setup

1. Copy the `motion.path.sim` folder into your Kit extensions directory, e.g.:

   ```
   <kit-app-root>/exts/motion.path.sim/
   ```

2. Open **Window → Extensions** in USD Composer / Omniverse Code.

3. Search for **"Motion Path Sim"** and toggle it **on**.

4. The **Motion Path Sim** panel appears (dock it or leave it floating).

---

## Picking prims

| Field | What to put here |
|-------|-----------------|
| **Path Prim** | An absolute USD prim path to a `BasisCurves` (or any prim with a `points` attribute), e.g. `/World/PathCurve` |
| **Target Prim** | An absolute USD prim path to the object you want to move, e.g. `/World/Vehicle` |

**Quick-pick**: select the prim in the viewport first, then click **Pick** next to the field.

---

## Usage walkthrough

### 1 – Create the path curve

In the Stage panel, create a **BasisCurves** prim (or import one from a USD file):

```
/World/PathCurve  (BasisCurves with 'points' attribute populated)
```

You can also use any prim whose attribute stores an array of `Vec3f` values.

### 2 – Place the target prim

```
/World/Vehicle  (any Xformable prim)
```

### 3 – Configure the panel

| Setting | Recommended value |
|---------|------------------|
| Path Prim | `/World/PathCurve` |
| Target Prim | `/World/Vehicle` |
| Duration | `5.0` s (adjust to taste) |
| Align to path | ☑ to rotate the vehicle along the tangent |
| Apply orientation | ☑ if Align is also on |

### 4 – Build the graph

Click **Build Graph**.  This creates the OmniGraph at:

```
/World/Graphs/MotionPathSimGraph
```

and wires the three nodes together.  The target prim snaps to the start of
the path immediately (normalizedTime = 0).

### 5 – Play back

| Button | Action |
|--------|--------|
| **Start** | Begins playback from t=0 |
| **Pause** | Freezes elapsed time |
| **Resume** (same button) | Continues from where it paused |
| **Stop** | Resets to t=0 and stops |

Status text below the buttons reflects the current `PlaybackState`.

> **Tip**: You can click **Start** without pressing **Build Graph** first — the
> panel will auto-build the graph on the first Start press.

---

## Graph wiring diagram

```
┌──────────────────────┐       ┌──────────────────────┐       ┌────────────────────┐
│   ReadPathPoints     │       │   PathInterpolate     │       │    ApplyXform       │
│                      │       │                        │       │                    │
│  in: primPath        │       │  in: points   ◄───────┼───────┤ (from left)        │
│  in: attributeName   │──────►│  in: pointCount        │       │  in: position ◄───┤
│                      │       │  in: normalizedTime ◄──┼── PlaybackController      │
│  out: points ────────┼──────►│  in: align             │       │  in: orientation◄─┤
│  out: pointCount ────┼──────►│                        │       │  in: targetPrimPath│
│                      │       │  out: position ─────────┼──────►│                    │
└──────────────────────┘       │  out: orientation ──────┼──────►│                    │
                               └──────────────────────┘       └────────────────────┘
```

`normalizedTime` is written directly to `PathInterpolate.inputs:normalizedTime`
each app frame by `PlaybackController`; there is no separate Variable node needed.

---

## OGN node reference

### `motion.path.sim.ReadPathPoints`

| Port | Direction | Type | Default | Description |
|------|-----------|------|---------|-------------|
| `primPath` | input | `token` | `""` | USD prim path |
| `attributeName` | input | `token` | `"points"` | Attribute to read |
| `points` | output | `pointf[3][]` | — | Array of 3-D points |
| `pointCount` | output | `int` | — | Number of points |

### `motion.path.sim.PathInterpolate`

| Port | Direction | Type | Default | Description |
|------|-----------|------|---------|-------------|
| `points` | input | `pointf[3][]` | — | Waypoints |
| `pointCount` | input | `int` | `0` | Count |
| `normalizedTime` | input | `float` | `0.0` | Progress [0, 1] |
| `align` | input | `bool` | `false` | Compute tangent orientation |
| `position` | output | `pointf[3]` | `[0,0,0]` | Interpolated position |
| `orientation` | output | `quatf` | identity | `[x,y,z,w]` quaternion |

### `motion.path.sim.ApplyXform`

| Port | Direction | Type | Default | Description |
|------|-----------|------|---------|-------------|
| `targetPrimPath` | input | `token` | `""` | Destination prim |
| `position` | input | `pointf[3]` | `[0,0,0]` | Translation |
| `orientation` | input | `quatf` | identity | Rotation `[x,y,z,w]` |
| `applyOrientation` | input | `bool` | `false` | Write orient op |

---

## Known limitations

| Limitation | Notes |
|------------|-------|
| **Linear interpolation only** | No Catmull-Rom / Bezier spline fitting; add arc-length re-parameterisation for constant-speed motion |
| **Z-up world space** | The path tangent reference forward vector is `+X` in Z-up. Flip to `+Y` for Y-up scenes |
| **BasisCurves assumed** | Any prim with a `pointf[3][]` attribute works, but only the `points` attribute is auto-configured |
| **No arc-length parameterisation** | Dense segments near curve endpoints will feel faster/slower with default linear t |
| **Single active graph** | Only one graph at `/World/Graphs/MotionPathSimGraph` is managed; multi-object use requires duplicating the graph manually |
| **Xform op order** | `ApplyXform` adds `translateOp` then `orientOp`; if the prim has existing ops in a different order, results may be wrong — clear xform ops first |

---

## Example USD snippet

```usda
def BasisCurves "PathCurve" {
    uniform token type = "linear"
    int[] curveVertexCounts = [5]
    point3f[] points = [
        (0, 0, 0),
        (100, 0, 0),
        (200, 50, 0),
        (300, 50, 0),
        (400, 0, 0)
    ]
}

def Xform "Vehicle" {
    double3 xformOp:translate = (0, 0, 0)
    uniform token[] xformOpOrder = ["xformOp:translate"]
}
```

Set **Path Prim** = `/World/PathCurve`, **Target Prim** = `/World/Vehicle`,
click **Build Graph**, then **Start**.
